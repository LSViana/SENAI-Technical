package wstemplate.project.models;

public enum UserType {

	ADMINISTRATOR, REGULAR
	
}
